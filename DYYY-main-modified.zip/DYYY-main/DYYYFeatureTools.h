#import <UIKit/UIKit.h>

@interface DYYYFeatureSearchViewController : UITableViewController
- (instancetype)initWithCatalog:(NSArray<NSDictionary *> *)catalog categoryActions:(NSDictionary<NSString *, dispatch_block_t> *)actions;
@end

@interface DYYYVoicePackViewController : UITableViewController
@end

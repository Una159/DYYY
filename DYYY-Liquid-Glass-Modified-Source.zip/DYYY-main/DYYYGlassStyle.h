#import <UIKit/UIKit.h>

/// Shared system-adaptive liquid-glass styling for DYYY-owned UI.
static inline UIVisualEffectView *DYYYCreateGlassView(CGRect frame, CGFloat radius) {
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial];
    UIVisualEffectView *glass = [[UIVisualEffectView alloc] initWithEffect:effect];
    glass.frame = frame;
    glass.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    glass.userInteractionEnabled = NO;
    glass.layer.cornerRadius = radius;
    glass.layer.masksToBounds = YES;
    glass.layer.borderWidth = 0.75;
    glass.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.30].CGColor;
    return glass;
}
